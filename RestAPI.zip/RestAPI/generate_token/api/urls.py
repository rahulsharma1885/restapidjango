from django.urls import path
from . import views

urlpatterns = [
    path('stu/', views.StudentApi.as_view()),
    path('stu/int:id', views.StudentApi2.as_view()),

]
