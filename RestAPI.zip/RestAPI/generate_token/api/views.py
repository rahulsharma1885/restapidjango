# from django.shortcuts import render
# from rest_framework.views import APIView
from .models import Student
from.serializers import StudentSerializer
from rest_framework import generics

# from rest_framework.authentication import SessionAuthentication
# from rest_framework.authentication import TokenAuthentication
# from rest_framework.permissions import IsAuthenticated

# Create your views here.
class StudentApi(generics.ListAPIView, generics.CreateAPIView):
    queryset= Student.objects.all()
    serializer_class = StudentSerializer

    # authentication_classes= [SessionAuthentication]
    # authentication_classes= [TokenAuthentication]
    # Permission_classes = [IsAuthenticated]

class StudentApi2(generics.UpdateAPIView, generics.DestroyAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    lookup_field= 'id'