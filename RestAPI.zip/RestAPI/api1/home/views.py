# from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
# Create your views here.

@api_view()
def course(request):
    return Response({
        'status':200,
        'message': ' Django!! rest_api is working..'
    })


# @api_view(['GET', 'POST', 'PUT']) #allow krte hai ase krke 'GET', 'POST', 'PUT', 'PATCH'
# def course(request):
#     if request.method == 'GET':
#         return Response({
#             'status': 200,
#             'message': 'Thank you!!',
#             'method': 'you called GET method'
#         })
    
#     elif request.method== 'POST':
#         return Response({
#             'status': 200,
#             'message': 'Thank you!!',
#             'method': 'you called POST method'
#        }) 
    
#     elif request.method== 'PUT':
#         return Response({
#             'status': 200,
#             'message': 'Thank you!!',
#             'method': 'you called PUT method'
#        })  

#     else:
#         return Response({
#             'status': 400,
#             'message': 'Thank you!!',
#             'method': 'invalid method'
#        }) 
