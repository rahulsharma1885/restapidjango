from .models import *
from .serializers import StudentSerializer
from rest_framework import generics

class StudentGeneric(generics.ListAPIView, generics.CreateAPIView):
    queryset= Student.objects.all()
    serializer_class= StudentSerializer


class StudentGeneric1(generics.UpdateAPIView, generics.DestroyAPIView):
    queryset= Student.objects.all()
    serializer_class= StudentSerializer
    lookup_field = 'id'
