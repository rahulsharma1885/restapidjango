from django.urls import path
from . import views
urlpatterns = [
    
    path('stu1/', views.StudentGeneric.as_view()),
    # path('stu2/<int:id>', views.StudentGeneric1.as_view()),
]
