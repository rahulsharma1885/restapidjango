# from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework import generics

# Create your views here.

class StudentAPI(generics.ListAPIView, generics.CreateAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

class StudentAPI2(generics.UpdateAPIView, generics.DestroyAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    lookup_field = 'id'