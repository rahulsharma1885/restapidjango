from django.db import models
# Create your models here.

class BaseStudent(models.Model):
    college= models.CharField(max_length=50)


class Student(BaseStudent):
    name= models.CharField(max_length=100)
    age= models.IntegerField()

