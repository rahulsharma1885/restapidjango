from .models import*
from rest_framework import serializers

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model= Student
        fields= ['name', 'about', 'phone']
        # fields= '__all__'