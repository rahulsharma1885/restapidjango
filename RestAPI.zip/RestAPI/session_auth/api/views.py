# from django.shortcuts import render
from .serializers import StudentSerializer
from .models import*
from rest_framework import viewsets
from rest_framework.authentication import SessionAuthentication
from rest_framework.permissions import IsAuthenticated, AllowAny, IsAdminUser, IsAuthenticatedOrReadOnly, DjangoModelPermissions
# Create your views here.

class StudentModelViewSet(viewsets.ModelViewSet):
    queryset= Student.objects.all()
    serializer_class= StudentSerializer
    authentication_classes= [SessionAuthentication]
    Permission_classes= [IsAuthenticated]
    # Permission_classes= [DjangoModelPermissions]
    # Permission_classes= [IsAuthenticatedOrReadOnly]

