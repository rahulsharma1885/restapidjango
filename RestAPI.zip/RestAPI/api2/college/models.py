from django.db import models

# Create your models here.
class BaseModel(models.Model):
    course= models.CharField(max_length=50)


class Student(BaseModel):
    name= models.CharField(max_length=100)
    age= models.IntegerField(default=50)