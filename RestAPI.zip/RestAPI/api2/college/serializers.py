from rest_framework import serializers
from .models import *

class StudentSerializers(serializers.ModelSerializer):
    class Meta:
        model= Student
        fields= ['id','name', 'age', 'course']

        # exclude=['age'] only ek field ko hi print krega
        # fields= '__all__'

