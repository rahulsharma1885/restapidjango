# from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import *
from .serializers import StudentSerializers
# from rest_framework.views import APIView

# class TransformerList(APIView):
    
############# function based ##################

@api_view(['GET'])
def get_student(request):
    obj= Student.objects.all()
    serializer=StudentSerializers(obj, many=True)

    return Response({
        'status': True, #200
        'message' :'hello dosto',
        'fetch_data': serializer.data
    })



@api_view(['PUT'])
def post_student(request):
    try:
        data= request.data
        print(data)
        serializer= StudentSerializers(data= request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'status': True, 'message': 'successful','post_data': serializer.data})
    except Exception as e:
        print(e)
    return Response({'status': False,'message': 'something went wrong' })

@api_view(['PUT'])
def put_student(request, pk):
    obj= Student.objects.get(pk=pk) 
    serializer= StudentSerializers(instance=obj , data= request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({
            "status":True,
            "fetch_data": serializer.data,
        })
    else:
        return Response(status= status.HTTP_404_NOT_FOUND)

@api_view(['PATCH'])
def petch_student(request, pk):
    obj=Student.objects.get(pk=pk)
    serializer= StudentSerializers(instance=obj , data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response({
            "status": True,
            "fetch_data":serializer.data,
            "message":"success"
        })
    else:
        return Response(status= status.HTTP_404_NOT_FOUND)
    
@api_view(['DELETE'])
def delete_student(request, pk):
    obj=Student.objects.get(pk=pk)
    obj.delete()
    return Response(status= status.HTTP_202_ACCEPTED)