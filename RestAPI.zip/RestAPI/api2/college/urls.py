from django.urls import path
from . import views

# from rest_framework.urlpatterns import format_suffix_patterns

urlpatterns = [
    path('get_student/', views.get_student, name='get_student'),
    path('add/', views.post_student, name='post-student'),
    path('update/<int:pk>', views.put_student, name='put_student'),
    path('modify/<int:pk>', views.petch_student, name='petch_student'),
    path('remove/<int:pk>', views.delete_student, name='delete_student'),


    # path('getstu/', StudentApi.as_view()),

    # path('getstu/', views.TransformerList.as_view()),
    # path('getstu/<int:pk>/', views.TransformerDetail.as_view()),

]  
  
# urlpatterns = format_suffix_patterns(urlpatterns)