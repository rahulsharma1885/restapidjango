# from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.views import APIView  ## class ke liye
from .models import Student
from .serializers import StudentSerializer
# Create your views here.

class StudentApi(APIView):
    def get(self, request, pk=None, format=None):
        id=pk
        if id is not None:
            obj= Student.objects.get(id=id)
            serializer= StudentSerializer(obj)
            return Response({'fetch_data': serializer.data})
    
        obj= Student.objects.all()
        serializer= StudentSerializer(obj, many=True)
        return Response({'fetch_data': serializer.data})



    def post(self, request, format=None):
        serializer= StudentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message':'data created'})
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        

    def put(self, request, pk=None, format=None):
        id=pk
        obj= Student.objects.get(pk=id)
        serializer= StudentSerializer(obj, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": 'updated'})
        return Response(serializer.errors)

    def patch(self, request, pk=None, format=None):
        id= pk
        obj= Student.objects.get(pk=id)
        serializer= StudentSerializer(obj, data= request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'partially updated'})
        
        return Response(serializer.errors)

    def delete(self, request,pk=None, format=None):
        id=pk
        obj= Student.objects.get(pk=id)
        obj.delete()
        return Response({"message":"deleted data"})