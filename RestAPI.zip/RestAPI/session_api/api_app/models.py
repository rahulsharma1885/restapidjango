from django.db import models

# Create your models here.

class BaseClass(models.Model):
    college= models.CharField(max_length=50)
    course= models.CharField(max_length=40)

class Student(BaseClass):
    name= models.CharField(max_length=100)
    roll_no= models.IntegerField()